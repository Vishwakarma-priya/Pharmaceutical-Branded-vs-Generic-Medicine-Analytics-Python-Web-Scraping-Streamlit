# Pharmaceutical Dataset Collection & Analytics

## What is included
- `data/branded_medicines.csv`: real branded medicine records sourced from 1mg pages surfaced during research.
- `data/generic_medicines.csv`: real PMBI government-generic records from the publicly indexed PMBI MRP PDF.
- `scripts/data_collection.py`: live Playwright collector.
- `scripts/capture_evidence.py`: evidence screenshot capture.
- `app.py`: Streamlit dashboard.
- `report.pdf`: methodology/evidence report.
- `evidence_screenshots/`: folder for runtime screenshots.

## Important evidence/data note
The current PMBI product-list page is JavaScript-driven. The collector therefore opens the live page and clicks its visible **Download CSV** control instead of relying on a hidden/private endpoint. The included generic CSV is a verified historical PMBI seed only; run the collector before submission to obtain the current live PMBI export.

The included branded CSV contains real records, not synthetic/Kaggle data. Prices are source-page MRPs and can vary by batch/date. The dashboard deliberately warns against mixing historical PMBI prices with current 1mg prices for a false price-gap conclusion.

## Run
1. Create a virtual environment.
2. `pip install -r requirements.txt`
3. `playwright install chromium`
4. `python scripts/data_collection.py`
5. Review `data/branded_medicines_live.csv` and `data/generic_medicines_live.csv`.
6. Replace/rename the live files as the final cleaned files if validation passes.
7. `python scripts/capture_evidence.py`
8. `streamlit run app.py`

## Cleaning checks
- Remove duplicate product names.
- Normalize salt names and dosage units.
- Convert MRP to numeric.
- Preserve source URL and source date.
- Do not impute missing MRP/manufacturer values from guesses.
- For price-gap analysis, match active composition + comparable pack size + comparable collection period.

## Source verification
Government generic source: PMBI/Janaushadhi product/MRP catalogue.
Commercial branded source: Tata 1mg product pages.
Regulatory/context source: CDSCO and Department of Pharmaceuticals.
